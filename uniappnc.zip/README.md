功能介绍
一款可以匿名通知用户挪车的微信小程序，保护用户和车主隐私。
功能特性
1、用户可以通过扫描小程序码联系到车主 
2、采用匿名通话的方式，用户只能在有效期内拨打车主电话，过期失效，从而保护车主和用户隐私。
3、后台可对用户订单，绑定用户，挪车码等进行管理
4、提供多种通知方式供用户选择。
5、支持微信公众号消息通知，将用户引流到微信公众号，增加公众号粉丝。
6.后台采用php+mysql开发，支持二次开发，定制开发
后台暂不开源，有需要后台的朋友可以联系微信：tunan6666666
体验小程序
![image.png](https://cdn.fastadmin.net/uploads/2022/10/12/f3f3c5632d5b48e7b05bdf47082c7773.jpg)
如需接受微信通知，请先关注公众号
![image.png](https://cdn.fastadmin.net/uploads/2022/10/12/7bb5fad244cb931399549aec9faffeca.png)
[后台网址](https://tn.rdtxgj.com/MNQYRauFiC.php/index/login "体验网址")账号：test 密码：testtest